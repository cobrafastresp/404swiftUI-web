//
//  Animation404SwiftUIApp.swift
//  Animation404SwiftUI
//
//  Created by Shreyas Vilaschandra Bhike on 17/10/20.
//

import SwiftUI

@main
struct Animation404SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
